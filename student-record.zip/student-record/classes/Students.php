<?php

    require_once "config/model.php";
    require_once "config/db.php";

    class Students extends Model {
        protected $conn;

        public function __construct($firstname, $lastname, $course, $address, $dob) {
            parent::__construct($firstname, $lastname, $course, $address, $dob);
            $database = new Database();
            $this->conn = $database->getConnection();
        }
        
        public function insertStudent() {
            return $this->create();
        }

        public function showStudent() {
            return $this->read();
        }

        public function updateStudent($id, $firstname, $lastname, $course, $address, $dob) {
            return $this->update($id, $firstname, $lastname, $course, $address, $dob);
        }

        public function deleteStudent($id) {
            return $this->delete($id);
        }
    }
?>
