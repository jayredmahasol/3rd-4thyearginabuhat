<?php
    require_once 'classes/Students.php';

    $students = new Students("", "", "", "","");
    $displayStudents = $students->showStudent();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Students Lists</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body class="bg-gray-50 font-sans text-gray-800">

    <div class="max-w-6xl mx-auto my-10 bg-white p-8 rounded-lg shadow-2xl">
        <h2 class="text-3xl font-semibold mb-6 text-center text-indigo-600">Students Lists</h2>

        <div class="overflow-x-auto rounded-lg shadow-md">
            <table class="min-w-full text-sm text-left text-gray-500">
                <thead class="bg-indigo-100 text-indigo-700">
                    <tr>
                        <th class="px-6 py-4 font-medium">First Name</th>
                        <th class="px-6 py-4 font-medium">Last Name</th>
                        <th class="px-6 py-4 font-medium">Course</th>
                        <th class="px-6 py-4 font-medium">Address</th>
                        <th class="px-6 py-4 font-medium">Date of Birth</th>
                        <th class="px-6 py-4 font-medium">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($displayStudents as $row) : ?>
                        <tr class="border-b hover:bg-indigo-50">
                            <td class="px-6 py-4"><?= htmlspecialchars($row['firstname']); ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($row['lastname']); ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($row['course']); ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($row['address']); ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($row['dob']); ?></td>
                            <td class="px-6 py-4">
                                <div class="flex space-x-2">
                                    <a href="update_student.php?id=<?= $row['id']; ?>" class="bg-yellow-400 hover:bg-yellow-500 text-white font-semibold px-3 py-1 rounded">
                                        Update
                                    </a>
                                    <a href="delete_student.php?id=<?= $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this student?');" class="bg-red-500 hover:bg-red-600 text-white font-semibold px-3 py-1 rounded">
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <br><br>

        <a href="index.php" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded"> Add Students </a>
    </div>

</body>
</html>
