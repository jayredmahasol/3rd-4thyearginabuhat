<?php
    require_once 'classes/Students.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $firstname = htmlspecialchars($_POST['firstname']);
        $lastname = htmlspecialchars($_POST['lastname']);
        $course = htmlspecialchars($_POST['course']);
        $address = htmlspecialchars($_POST['address']);
        $dob = $_POST['dob'];
    
        $students = new Students($firstname, $lastname, $course, $address, $dob);
        $students->insertStudent();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Student Information Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2 class="mb-4">Student Information Form</h2>

        <?php if ($_SERVER["REQUEST_METHOD"] == "POST"): ?>
            <div class="alert alert-success" role="alert">
                Student information saved successfully!
            </div>
        <?php endif; ?>

        <form method="POST" action="index.php">
            <div class="form-group">
                <label for="firstname">First Name:</label>
                <input type="text" name="firstname" id="firstname" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="lastname">Last Name:</label>
                <input type="text" name="lastname" id="lastname" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="course">Course:</label>
                <input type="text" name="course" id="course" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" name="address" id="address" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <input type="date" name="dob" id="dob" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Save Student</button>
            <a href="students_list.php" class="btn btn-primary">View Students List</a>
        </form>
    </div>
</body>
</html>