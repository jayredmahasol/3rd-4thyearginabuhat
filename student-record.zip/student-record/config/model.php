<?php
    require_once "config/db.php";

    class Model {
        protected $conn;
        public $firstname;
        public $lastname;
        public $address;
        public $course;
        public $dob;

        public function __construct($firstname, $lastname, $course, $address, $dob){
            $database = new Database();
            $this->conn = $database->getConnection();
            
            $this->firstname = $firstname;
            $this->lastname = $lastname;
            $this->course = $course;
            $this->address = $address;
            $this->dob = $dob;
        }
        public function create() {
            $query = "INSERT INTO students (firstname, lastname, course, address, dob) 
                    VALUES (:firstname, :lastname, :course, :address, :dob)";

            $stmt = $this->conn->prepare($query);

            $stmt->bindParam(':firstname', $this->firstname);
            $stmt->bindParam(':lastname', $this->lastname);
            $stmt->bindParam(':course', $this->course);
            $stmt->bindParam(':address', $this->address);
            $stmt->bindParam(':dob', $this->dob);

            if ($stmt->execute()) {
                echo "Student record saved successfully.";
            } else {
                echo "Error saving student record.";
            }
        }

        public function read() {
            $query = "SELECT id, firstname, lastname, course, address, dob FROM students";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        public function update($id, $firstname, $lastname, $course, $address, $dob) {
            $query = "UPDATE students SET firstname = :firstname, lastname = :lastname, course = :course, address = :address, dob = :dob 
                    WHERE id = :id";
    
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
    
            $stmt->bindParam(':firstname', $firstname);
            $stmt->bindParam(':lastname', $lastname);
            $stmt->bindParam(':course', $course);
            $stmt->bindParam(':address', $address);
            $stmt->bindParam(':dob', $dob);
            
            return $stmt->execute();
        }

        public function delete($id) {

            $query = "DELETE FROM students WHERE id = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
    
            return $stmt->execute();          
        }

        public function getStudentById($id) {
            $query = "SELECT id, firstname, lastname, course, address, dob FROM students WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
        
            // Fetch the result
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if ($student) {
                return $student;  // Return the student data
            } else {
                return null;  // Return null if no student found
            }
        }
    }

?>