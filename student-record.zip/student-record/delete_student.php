<?php
require_once 'classes/Students.php';


    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        
        $students = new Students("", "", "", "", "");
        
        if ($students->deleteStudent($id)) {
            header("Location: students_list.php");
            exit;
        } else {
            echo "Failed to delete student.";
        }
    } else {
        echo "No student ID provided.";
    }
    
?>
