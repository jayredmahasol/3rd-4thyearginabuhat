<?php
    require_once 'classes/Students.php';

    $displayStudents = null;
    $message = "";
    $messageType = ""; 
    if (!isset($_GET['id'])) {
        die("ID not provided.");
    }


    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $students = new Students("", "", "", "", "");
        
        $displayStudents = $students->getStudentById($id);

    if (!$displayStudents) {
        $message = "Student not found!";
        $messageType = "error";
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = htmlspecialchars($_POST['firstname']);
    $lastname = htmlspecialchars($_POST['lastname']);
    $course = htmlspecialchars($_POST['course']);
    $address = htmlspecialchars($_POST['address']);
    $dob = $_POST['dob'];

    $students = new Students($firstname, $lastname, $course, $address, $dob);
    
    try {
        $students->updateStudent($id, $firstname, $lastname, $course, $address, $dob);
        $message = "Student updated successfully!";
        $messageType = "success";
        // Refresh the updated data
        $displayStudents = $students->getStudentById($id);
    } catch (Exception $e) {
        $message = "Failed to update student: " . $e->getMessage();
        $messageType = "error";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Student</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">

    <div class="bg-white p-10 rounded-lg shadow-xl w-full max-w-xl">

        <h2 class="text-2xl font-bold text-indigo-600 mb-6 text-center">Edit Student</h2>

        <!-- Notification Message -->
        <?php if (!empty($message)): ?>
            <div class="mb-4 px-4 py-3 rounded-lg text-white
                <?= $messageType === 'success' ? 'bg-green-500' : 'bg-red-500' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <?php if ($displayStudents): ?>
        <form method="POST" class="space-y-5">
            <div>
                <label class="block text-gray-700 font-semibold mb-1">First Name</label>
                <input type="text" name="firstname" value="<?= htmlspecialchars($displayStudents['firstname']) ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400" required>
            </div>

            <div>
                <label class="block text-gray-700 font-semibold mb-1">Last Name</label>
                <input type="text" name="lastname" value="<?= htmlspecialchars($displayStudents['lastname']) ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400" required>
            </div>

            <div>
                <label class="block text-gray-700 font-semibold mb-1">Course</label>
                <input type="text" name="course" value="<?= htmlspecialchars($displayStudents['course']) ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400" required>
            </div>

            <div>
                <label class="block text-gray-700 font-semibold mb-1">Address</label>
                <input type="text" name="address" value="<?= htmlspecialchars($displayStudents['address']) ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400" required>
            </div>

            <div>
                <label class="block text-gray-700 font-semibold mb-1">Date of Birth</label>
                <input type="date" name="dob" value="<?= htmlspecialchars($displayStudents['dob']) ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-400" required>
            </div>

            <div class="flex justify-between items-center mt-6">
                <a href="students_list.php" class="text-sm text-gray-600 hover:underline">Cancel</a>
                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg">
                    Save Changes
                </button>
            </div>
        </form>
        <?php endif; ?>
    </div>

</body>
</html>
